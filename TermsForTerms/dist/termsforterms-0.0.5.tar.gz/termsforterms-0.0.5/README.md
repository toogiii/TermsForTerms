TermsForTerms

TermsForTerms is a graphical framework that allows simple expression of privacy policy in .tft files. These are then translated into visualizable graphs which can be merged or reconciled for legal compliance checks. See more info at the homepage below.

GitHub: https://github.com/toogiii/TermsForTerms